execute at @p positioned 0.0 0.3 0.0 run summon marker ^ ^ ^1 {Tags:["temp"]}
execute at @p positioned ~ ~1 ~ summon fireball run data modify entity @s Motion set from entity @n[type=marker,tag=temp] Pos
scoreboard players reset @s click
kill @e[tag=temp]
