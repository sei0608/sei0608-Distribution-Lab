scoreboard objectives add click minecraft.used:carrot_on_a_stick

forceload add 0 0 0 0