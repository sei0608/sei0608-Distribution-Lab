execute if score $countdown countdown matches 0.. run scoreboard players remove $countdown countdown 1
execute if score $countdown countdown matches 200 run title @a title "10"
execute if score $countdown countdown matches 200 run playsound block.note_block.harp ambient @a
execute if score $countdown countdown matches 60 run title @a title "3"
execute if score $countdown countdown matches 60 run playsound block.note_block.harp ambient @a
execute if score $countdown countdown matches 40 run title @a title "2"
execute if score $countdown countdown matches 40 run playsound block.note_block.harp ambient @a
execute if score $countdown countdown matches 20 run title @a title "1"
execute if score $countdown countdown matches 20 run playsound block.note_block.harp ambient @a
execute if score $countdown countdown matches 0 run title @a title "スタート"
execute if score $countdown countdown matches 0 if score $random countdown matches 1 run playsound entity.lightning_bolt.thunder ambient @a
execute if score $countdown countdown matches 0 if score $random countdown matches 2 run playsound item.goat_horn.sound.0 ambient @a
execute if score $countdown countdown matches 0 run gamemode survival @a