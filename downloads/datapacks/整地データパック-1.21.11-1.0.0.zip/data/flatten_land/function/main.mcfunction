execute as @e[type=item,nbt=!{Item:{components:{"minecraft:custom_data":{string:none}}}}] at @s store result score @p itemcount run data get entity @s Item.count
execute as @e[type=item,nbt=!{Item:{components:{"minecraft:custom_data":{string:none}}}}] at @s run kill @s
kill @e[type=item,nbt={Item:{id:"minecraft:carrot_on_a_stick"}}]

execute as @a at @s unless items entity @s inventory.* minecraft:carrot_on_a_stick unless items entity @s hotbar.* minecraft:carrot_on_a_stick unless items entity @s weapon.* minecraft:carrot_on_a_stick run give @s minecraft:carrot_on_a_stick[custom_data={string:none},minecraft:item_model=slime_ball]

execute as @a at @s if score @s itemcount matches 1.. run scoreboard players operation @s points += @s itemcount

execute as @a at @s if score @s itemcount matches 1.. run title @s actionbar [{"color":"gold","text":"+"},{"color":"gold","score":{"name":"@s","objective":"itemcount"}},{"color":"gold","text":"ポイント"}]


execute as @a at @s if score @s itemcount matches 1.. run scoreboard players reset @s itemcount

function flatten_land:buy
function flatten_land:countdown
execute store result score $random countdown run random value 1..2
scoreboard players enable @a buy
dialog show @a[scores={shop=1..}] flatten_land:shop
scoreboard players reset @a[scores={shop=1..}] shop