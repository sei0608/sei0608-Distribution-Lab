scoreboard players set $countdown countdown 200
gamemode adventure @a
scoreboard players reset @a points