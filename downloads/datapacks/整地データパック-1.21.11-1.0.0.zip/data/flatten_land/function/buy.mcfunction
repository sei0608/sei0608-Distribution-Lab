# 木のツール
give @a[scores={buy=11,points=10..}] wooden_sword[custom_data={string:none}]
give @a[scores={buy=12,points=10..}] wooden_axe[custom_data={string:none}]
give @a[scores={buy=13,points=10..}] wooden_pickaxe[custom_data={string:none}]
give @a[scores={buy=14,points=10..}] wooden_shovel[custom_data={string:none}]
give @a[scores={buy=15,points=10..}] wooden_hoe[custom_data={string:none}]
give @a[scores={buy=16,points=10..}] wooden_spear[custom_data={string:none},enchantments={lunge:3}] 1
tellraw @a[scores={buy=11..16,points=..9}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=11..16,points=10..}] points 10

# 石のツール
give @a[scores={buy=21,points=30..}] stone_sword[custom_data={string:none}]
give @a[scores={buy=22,points=30..}] stone_axe[custom_data={string:none}]
give @a[scores={buy=23,points=30..}] stone_pickaxe[custom_data={string:none}]
give @a[scores={buy=24,points=30..}] stone_shovel[custom_data={string:none}]
give @a[scores={buy=25,points=30..}] stone_hoe[custom_data={string:none}]
give @a[scores={buy=26,points=30..}] stone_spear[custom_data={string:none},enchantments={lunge:3}] 1
tellraw @a[scores={buy=21..26,points=..29}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=21..26,points=30..}] points 30

# 銅のツール
give @a[scores={buy=31,points=80..}] copper_sword[custom_data={string:none}]
give @a[scores={buy=32,points=80..}] copper_axe[custom_data={string:none}]
give @a[scores={buy=33,points=80..}] copper_pickaxe[custom_data={string:none}]
give @a[scores={buy=34,points=80..}] copper_shovel[custom_data={string:none}]
give @a[scores={buy=35,points=80..}] copper_hoe[custom_data={string:none}]
give @a[scores={buy=36,points=80..}] copper_spear[custom_data={string:none},enchantments={lunge:3}] 1
tellraw @a[scores={buy=31..36,points=..79}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=31..36,points=80..}] points 80

# 鉄のツール
give @a[scores={buy=41,points=200..}] iron_sword[custom_data={string:none}]
give @a[scores={buy=42,points=200..}] iron_axe[custom_data={string:none}]
give @a[scores={buy=43,points=200..}] iron_pickaxe[custom_data={string:none}]
give @a[scores={buy=44,points=200..}] iron_shovel[custom_data={string:none}]
give @a[scores={buy=45,points=200..}] iron_hoe[custom_data={string:none}]
give @a[scores={buy=46,points=200..}] iron_spear[custom_data={string:none},enchantments={lunge:3}] 1
tellraw @a[scores={buy=41..46,points=..199}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=41..46,points=200..}] points 200

# ダイヤのツール
give @a[scores={buy=51,points=500..}] diamond_sword[custom_data={string:none}]
give @a[scores={buy=52,points=500..}] diamond_axe[custom_data={string:none}]
give @a[scores={buy=53,points=500..}] diamond_pickaxe[custom_data={string:none}]
give @a[scores={buy=54,points=500..}] diamond_shovel[custom_data={string:none}]
give @a[scores={buy=55,points=500..}] diamond_hoe[custom_data={string:none}]
give @a[scores={buy=56,points=500..}] diamond_spear[custom_data={string:none},enchantments={lunge:3}] 1
tellraw @a[scores={buy=51..56,points=..499}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=51..56,points=500..}] points 500

# ネザライトのツール
give @a[scores={buy=61,points=1000..}] netherite_sword[custom_data={string:none}]
give @a[scores={buy=62,points=1000..}] netherite_axe[custom_data={string:none}]
give @a[scores={buy=63,points=1000..}] netherite_pickaxe[custom_data={string:none}]
give @a[scores={buy=64,points=1000..}] netherite_shovel[custom_data={string:none}]
give @a[scores={buy=65,points=1000..}] netherite_hoe[custom_data={string:none}]
give @a[scores={buy=66,points=1000..}] netherite_spear[custom_data={string:none},enchantments={lunge:3}] 1
tellraw @a[scores={buy=61..66,points=..999}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=61..66,points=1000..}] points 1000

# 金のツール
give @a[scores={buy=71,points=20..}] golden_sword[custom_data={string:none}]
give @a[scores={buy=72,points=20..}] golden_axe[custom_data={string:none}]
give @a[scores={buy=73,points=20..}] golden_pickaxe[custom_data={string:none}]
give @a[scores={buy=74,points=20..}] golden_shovel[custom_data={string:none}]
give @a[scores={buy=75,points=20..}] golden_hoe[custom_data={string:none}]
give @a[scores={buy=76,points=20..}] wooden_spear[custom_data={string:none},enchantments={lunge:3}] 1
tellraw @a[scores={buy=71..76,points=..19}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=71..76,points=20..}] points 20

# 81: スポンジ (30pt)
give @a[scores={buy=81,points=30..}] sponge[custom_data={string:none}] 64
tellraw @a[scores={buy=82,points=..99}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=81,points=30..}] points 30

# 82: ステーキ (100pt)
give @a[scores={buy=82,points=100..}] cooked_beef[custom_data={string:none}] 64
tellraw @a[scores={buy=82,points=..99}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=82,points=100..}] points 100

# 83: エリトラ (300pt)
give @a[scores={buy=83,points=300..}] elytra[custom_data={string:none}]
tellraw @a[scores={buy=83,points=..299}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=83,points=300..}] points 300

# 84: ロケット花火 (100pt)
give @a[scores={buy=84,points=100..}] firework_rocket[fireworks={flight_duration:3},custom_data={string:none}] 64
tellraw @a[scores={buy=84,points=..99}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=84,points=100..}] points 100

# 85: バケツ (30pt)
give @a[scores={buy=85,points=30..}] bucket[custom_data={string:none}]
tellraw @a[scores={buy=85,points=..29}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=85,points=30..}] points 30

# 86: 足場 (20pt)
give @a[scores={buy=86,points=20..}] scaffolding[custom_data={string:none}] 64
tellraw @a[scores={buy=86,points=..19}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=86,points=20..}] points 20

# 87: 丸石 (10pt)
give @a[scores={buy=87,points=10..}] cobblestone[custom_data={string:none}] 64
tellraw @a[scores={buy=87,points=..9}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=87,points=10..}] points 10

# 91: 効率強化 (500pt)
give @a[scores={buy=91,points=500..}] nether_star[custom_data={string:"none"},attribute_modifiers=[{type:"mining_efficiency",amount:26.0,id:"offhand_efficiency",operation:"add_value",slot:"offhand"}]]
tellraw @a[scores={buy=91,points=..499}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=91,points=500..}] points 500

# 92: 効率強化 (1000pt)
give @a[scores={buy=92,points=1000..}] nether_star[custom_data={string:"none"},attribute_modifiers=[{type:"mining_efficiency",amount:101.0,id:"offhand_efficiency",operation:"add_value",slot:"offhand"}]]
tellraw @a[scores={buy=92,points=..999}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=92,points=1000..}] points 1000

# 93: 跳躍力増加 2ブロック (300pt)
give @a[scores={buy=93,points=300..}] nether_star[custom_data={string:"none"},attribute_modifiers=[{type:"jump_strength",amount:0.24,id:"jump_2blocks",operation:"add_value",slot:"offhand"}]]
tellraw @a[scores={buy=93,points=..299}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=93,points=300..}] points 300

# 94: 跳躍力増加 5ブロック (800pt)
give @a[scores={buy=94,points=800..}] nether_star[custom_data={string:"none"},attribute_modifiers=[{type:"jump_strength",amount:0.55,id:"jump_5blocks",operation:"add_value",slot:"offhand"}]]
tellraw @a[scores={buy=94,points=..799}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=94,points=800..}] points 800

# 95: リーチ増加 +1 (1000pt)
give @a[scores={buy=95,points=1000..}] nether_star[custom_data={string:"none"},attribute_modifiers=[{type:"block_interaction_range",id:"reach_up",amount:1.0,operation:"add_value",slot:"offhand"}]]
tellraw @a[scores={buy=95,points=..999}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=95,points=1000..}] points 1000

# 96: リーチ増加 +2 (2000pt)
give @a[scores={buy=96,points=2000..}] nether_star[custom_data={string:"none"},attribute_modifiers=[{type:"block_interaction_range",id:"reach_up_2",amount:2.0,operation:"add_value",slot:"offhand"}]]
tellraw @a[scores={buy=96,points=..1999}] "§4ポイントが足りません。"
scoreboard players remove @a[scores={buy=96,points=2000..}] points 2000

# スコアボード buy のリセット
scoreboard players reset @a[scores={buy=1..}] buy