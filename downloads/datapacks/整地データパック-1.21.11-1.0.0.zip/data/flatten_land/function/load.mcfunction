scoreboard objectives add points dummy
scoreboard objectives setdisplay sidebar points
scoreboard objectives add itemcount dummy
scoreboard objectives add buy trigger
scoreboard objectives add countdown dummy
scoreboard objectives add shop minecraft.used:minecraft.carrot_on_a_stick

gamerule mob_drops false


tellraw @a "データパックインストール完了"
